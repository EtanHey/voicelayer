/**
 * Socket protocol types for VoiceLayer <-> Voice Bar communication.
 *
 * Transport: Unix domain socket at /tmp/voicelayer.sock (Voice Bar is server, MCP is client).
 * Framing: Newline-delimited JSON (NDJSON) -- one JSON object per line, \n terminated.
 *
 * Both the Bun socket client and SwiftUI Voice Bar server must agree on these types.
 */

// --- Events: VoiceLayer → Voice Bar ---

export type VoiceLayerState =
  | "idle"
  | "speaking"
  | "recording"
  | "transcribing";

export interface StateEvent {
  type: "state";
  state: VoiceLayerState;
  /** Present when state is "speaking" — the text being spoken. */
  text?: string;
  /** Present when state is "speaking" — the voice being used. */
  voice?: string;
  /** Present when state is "recording" — the recording mode. */
  mode?: "vad" | "ptt";
  /** Present when state is "recording" with VAD — the silence mode. */
  silence_mode?: "quick" | "standard" | "thoughtful";
  /**
   * Source of idle events — lets Voice Bar distinguish playback-end from recording-end.
   * AIDEV-NOTE: Without this, a queued voice_speak audio finishing during a bar-initiated
   * recording resets barInitiatedRecording before the transcription arrives, killing paste.
   */
  source?: "playback" | "recording";
}

export interface SpeechEvent {
  type: "speech";
  /** true = voice activity detected, false = silence detected. */
  detected: boolean;
}

export interface TranscriptionEvent {
  type: "transcription";
  text: string;
  /** true = partial/streaming result, false = final result. */
  partial?: boolean;
}

export interface TranscriptionStatusEvent {
  type: "transcription_status";
  status: "warming" | "transcribing";
  message: string;
}

export interface AudioLevelEvent {
  type: "audio_level";
  /** RMS audio level 0.0–1.0. */
  rms: number;
}

export interface ErrorEvent {
  type: "error";
  message: string;
  /** true = transient error (will recover), false = needs user action. */
  recoverable: boolean;
  /** true = surface this error even during a bar-initiated recording. */
  show_during_bar_recording?: boolean;
  /** Machine-readable capture failure signal for VoiceBar daemon supervision. */
  capture_failure?: "broken-mic";
}

/** Word boundary from edge-tts WordBoundary event. */
export interface WordBoundary {
  /** Offset from start of audio in milliseconds. */
  offset_ms: number;
  /** Duration of the word in milliseconds. */
  duration_ms: number;
  /** The word text. */
  text: string;
}

/** Sent after TTS synthesis completes, before playback starts.
 *  Voice Bar uses these timestamps to drive karaoke word highlighting. */
export interface SubtitleEvent {
  type: "subtitle";
  /** Word boundaries with exact timing from the TTS engine. */
  words: WordBoundary[];
}

export type PlaybackPriority =
  | "critical"
  | "high"
  | "normal"
  | "low"
  | "background";

export interface QueueItemSnapshot {
  text: string;
  voice: string;
  priority: PlaybackPriority;
  is_current: boolean;
  /** Progress of the current item from 0.0 to 1.0. Queued items stay at 0. */
  progress: number;
}

export interface QueueEvent {
  type: "queue";
  /** Total queued + currently playing items. */
  depth: number;
  /** Ordered queue snapshot: current item first, then pending items. */
  items: QueueItemSnapshot[];
}

export type CommandModePhase =
  | "listening"
  | "capturing"
  | "applying"
  | "fallback"
  | "done"
  | "error";

export interface CommandModeEvent {
  type: "command_mode";
  phase: CommandModePhase;
  operation: "replace_selection" | "insert_below";
  prompt?: string;
  replacement_text?: string;
}

export interface ClipMarkerEvent {
  type: "clip_marker";
  marker_id: string;
  label: string;
  source: "tts" | "command";
  status: "marked" | "consumed";
}

export type IntentOutcome = "accept" | "noop" | "reject";

export type AckCommand =
  | "stop"
  | "cancel"
  | "replay"
  | "retranscribe_last"
  | "toggle"
  | "record"
  | "command"
  | "mark_clip"
  | "vocab_add"
  | "vocab_remove"
  | "vocab_add_term"
  | "vocab_remove_term";

export interface AckEvent {
  type: "ack";
  command: AckCommand;
  outcome: IntentOutcome;
  id?: string;
  reason?: string;
}

export type SocketEvent =
  | StateEvent
  | SpeechEvent
  | TranscriptionEvent
  | TranscriptionStatusEvent
  | AudioLevelEvent
  | ErrorEvent
  | SubtitleEvent
  | QueueEvent
  | CommandModeEvent
  | ClipMarkerEvent
  | AckEvent;

// --- Commands: Voice Bar → VoiceLayer ---

interface SocketCommandBase {
  id?: string;
}

export interface StopCommand extends SocketCommandBase {
  cmd: "stop";
}

export interface CancelCommand extends SocketCommandBase {
  cmd: "cancel";
}

export interface ReplayCommand extends SocketCommandBase {
  cmd: "replay";
}

export interface RetranscribeLastCommand extends SocketCommandBase {
  cmd: "retranscribe_last";
}

export interface ToggleCommand extends SocketCommandBase {
  cmd: "toggle";
  scope: "all" | "tts" | "mic";
  enabled: boolean;
}

export interface RecordCommand extends SocketCommandBase {
  cmd: "record";
  /** Recording timeout in seconds (default: 30, max: 3600). */
  timeout_seconds?: number;
  /** Silence detection mode (default: "standard"). */
  silence_mode?: "quick" | "standard" | "thoughtful";
  /** Push-to-talk mode — no VAD, stop via signal (default: false). */
  press_to_talk?: boolean;
}

export interface HealthCommand extends SocketCommandBase {
  cmd: "health";
}

export interface CommandModeCommand extends SocketCommandBase {
  cmd: "command";
  operation: "replace_selection" | "insert_below";
  text: string;
  prompt?: string;
}

export interface MarkClipCommand extends SocketCommandBase {
  cmd: "mark_clip";
  label: string;
  source?: "tts" | "command";
}

export interface VocabAddCommand extends SocketCommandBase {
  cmd: "vocab_add";
  from: string;
  to: string;
}

export interface VocabListCommand extends SocketCommandBase {
  cmd: "vocab_list";
}

export interface VocabRemoveCommand extends SocketCommandBase {
  cmd: "vocab_remove";
  from: string;
}

export interface VocabAddTermCommand extends SocketCommandBase {
  cmd: "vocab_add_term";
  term: string;
}

export interface VocabRemoveTermCommand extends SocketCommandBase {
  cmd: "vocab_remove_term";
  term: string;
}

export type SocketCommand =
  | StopCommand
  | CancelCommand
  | ReplayCommand
  | RetranscribeLastCommand
  | ToggleCommand
  | RecordCommand
  | HealthCommand
  | CommandModeCommand
  | MarkClipCommand
  | VocabAddCommand
  | VocabListCommand
  | VocabRemoveCommand
  | VocabAddTermCommand
  | VocabRemoveTermCommand;

export interface HealthResponse {
  type: "health";
  uptime_seconds: number;
  queue_depth: number;
  recording_state: "idle" | "recording" | "transcribing";
}

export interface VocabListResponse {
  type: "vocab_list";
  id?: string;
  updated_at: string | null;
  prompt_terms: string[];
  aliases: Array<{ from: string; to: string }>;
}

export type SocketResponse = HealthResponse | AckEvent | VocabListResponse;

// --- Serialization ---

/** Serialize an event to NDJSON (JSON + newline). */
export function serializeEvent(event: SocketEvent): string {
  return JSON.stringify(event) + "\n";
}

/** Parse a single JSON line into a SocketCommand. Returns null if invalid. */
export function parseCommand(line: string): SocketCommand | null {
  try {
    const parsed = JSON.parse(line);
    if (
      !parsed ||
      typeof parsed !== "object" ||
      typeof parsed.cmd !== "string"
    ) {
      return null;
    }
    const id = parseCommandId(parsed);
    switch (parsed.cmd) {
      case "stop":
        return withCommandId<StopCommand>({ cmd: "stop" }, id);
      case "cancel":
        return withCommandId<CancelCommand>({ cmd: "cancel" }, id);
      case "replay":
        return withCommandId<ReplayCommand>({ cmd: "replay" }, id);
      case "retranscribe_last":
        return withCommandId<RetranscribeLastCommand>(
          { cmd: "retranscribe_last" },
          id,
        );
      case "health":
        return withCommandId<HealthCommand>({ cmd: "health" }, id);
      case "command": {
        if (
          typeof parsed.text !== "string" ||
          parsed.text.trim().length === 0
        ) {
          return null;
        }
        const operation =
          parsed.operation === "insert_below"
            ? "insert_below"
            : "replace_selection";
        return withCommandId<CommandModeCommand>(
          {
            cmd: "command",
            operation,
            text: parsed.text,
            prompt:
              typeof parsed.prompt === "string" ? parsed.prompt : undefined,
          },
          id,
        );
      }
      case "mark_clip": {
        if (
          typeof parsed.label !== "string" ||
          parsed.label.trim().length === 0
        ) {
          return null;
        }
        return withCommandId<MarkClipCommand>(
          {
            cmd: "mark_clip",
            label: parsed.label,
            source: parsed.source === "tts" ? "tts" : "command",
          },
          id,
        );
      }
      case "vocab_add": {
        const from = parseRequiredString(parsed.from);
        const to = parseRequiredString(parsed.to);
        if (!from || !to) return null;
        return withCommandId<VocabAddCommand>(
          {
            cmd: "vocab_add",
            from,
            to,
          },
          id,
        );
      }
      case "vocab_list":
        return withCommandId<VocabListCommand>({ cmd: "vocab_list" }, id);
      case "vocab_remove": {
        const from = parseRequiredString(parsed.from);
        if (!from) return null;
        return withCommandId<VocabRemoveCommand>(
          {
            cmd: "vocab_remove",
            from,
          },
          id,
        );
      }
      case "vocab_add_term": {
        const term = parseRequiredString(parsed.term);
        if (!term) return null;
        return withCommandId<VocabAddTermCommand>(
          {
            cmd: "vocab_add_term",
            term,
          },
          id,
        );
      }
      case "vocab_remove_term": {
        const term = parseRequiredString(parsed.term);
        if (!term) return null;
        return withCommandId<VocabRemoveTermCommand>(
          {
            cmd: "vocab_remove_term",
            term,
          },
          id,
        );
      }
      case "toggle": {
        if (typeof parsed.enabled !== "boolean") return null;
        const scope = parsed.scope;
        if (scope !== "all" && scope !== "tts" && scope !== "mic") {
          return withCommandId(
            {
              cmd: "toggle",
              scope: "all",
              enabled: parsed.enabled,
            } satisfies ToggleCommand,
            id,
          );
        }
        return withCommandId(
          {
            cmd: "toggle",
            scope,
            enabled: parsed.enabled,
          } satisfies ToggleCommand,
          id,
        );
      }
      case "record": {
        const command: RecordCommand = withCommandId(
          {
            cmd: "record",
          },
          id,
        );
        if (typeof parsed.timeout_seconds === "number") {
          command.timeout_seconds = Math.max(
            5,
            Math.min(3600, parsed.timeout_seconds),
          );
        }
        if (
          parsed.silence_mode === "quick" ||
          parsed.silence_mode === "standard" ||
          parsed.silence_mode === "thoughtful"
        ) {
          command.silence_mode = parsed.silence_mode;
        }
        if (parsed.press_to_talk === true) {
          command.press_to_talk = true;
        }
        return command;
      }
      default:
        return null;
    }
  } catch {
    return null;
  }
}

function parseRequiredString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function parseCommandId(parsed: Record<string, unknown>): string | undefined {
  if (typeof parsed.id !== "string") return undefined;
  const id = parsed.id.trim();
  return id.length > 0 ? id : undefined;
}

function withCommandId<T extends object>(
  command: T,
  id?: string,
): T & { id?: string } {
  if (!id) return command;
  return {
    ...command,
    id,
  };
}
