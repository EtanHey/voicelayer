/**
 * Tests for dev-aware post-processing rule engine (rules-engine.ts).
 *
 * Seven stages in priority order:
 * 1. Filler removal
 * 2. Spoken punctuation
 * 3. Case formatting commands
 * 4. Number formatting
 * 5. Tech vocabulary
 * 6. Auto-capitalization
 * 7. Custom aliases
 *
 * Note: auto-capitalization runs last, so first word is always capitalized.
 * Tests reflect this — it's correct behavior for dictation output.
 */
import { describe, it, expect } from "bun:test";
import {
  applyRules,
  preserveCodeTokens,
  type RulesConfig,
} from "../rules-engine";

describe("rules-engine", () => {
  // --- Stage 1: Filler removal ---
  describe("filler removal", () => {
    it("removes common English fillers", () => {
      expect(applyRules("um I think uh this is basically working")).toBe(
        "I think this is working",
      );
    });

    it("removes fillers at start and end", () => {
      expect(applyRules("uh hello world um")).toBe("Hello world");
    });

    it("preserves discourse phrases instead of deleting spoken content", () => {
      expect(applyRules("you know the function I mean works")).toBe(
        "You know the function I mean works",
      );
    });

    it("removes 'like' as filler before intensifiers", () => {
      expect(applyRules("it's like really fast")).toBe("It's really fast");
    });

    it("handles multiple consecutive fillers", () => {
      expect(applyRules("um uh basically the code")).toBe("The code");
    });
  });

  // --- Stage 2: Spoken punctuation ---
  describe("spoken punctuation", () => {
    it("converts period/full stop", () => {
      expect(applyRules("hello world period")).toBe("Hello world.");
    });

    it("converts comma", () => {
      expect(applyRules("first comma second")).toBe("First, second");
    });

    it("converts question mark and exclamation", () => {
      expect(applyRules("what question mark")).toBe("What?");
      expect(applyRules("what questionmark")).toBe("What?");
      expect(applyRules("wow exclamation mark")).toBe("Wow!");
    });

    it("does not duplicate punctuation when STT already appended it", () => {
      expect(applyRules("what question mark?")).toBe("What?");
      expect(applyRules("what, question mark?")).toBe("What?");
      expect(applyRules("wow, exclamation mark!")).toBe("Wow!");
    });

    it("collapses mixed terminal punctuation around dictated question marks", () => {
      expect(applyRules("much better BrainLayer?.")).toBe(
        "Much better BrainLayer?",
      );
      expect(applyRules("much better BrainLayer.?.")).toBe(
        "Much better BrainLayer?",
      );
    });

    it("preserves dictated ellipses before terminal punctuation", () => {
      expect(applyRules("wait ellipsis question mark")).toBe("Wait...?");
      expect(applyRules("wait ellipsis exclamation mark")).toBe("Wait...!");
    });

    it("preserves dictated ellipses after terminal punctuation", () => {
      expect(applyRules("what question mark ellipsis")).toBe("What?...");
      expect(applyRules("wow exclamation mark ellipsis")).toBe("Wow!...");
    });

    it("preserves abbreviation periods before terminal punctuation", () => {
      expect(applyRules("are you from the U.S.?")).toBe(
        "Are you from the U.S.?",
      );
      expect(applyRules("are you from the U.S.?.")).toBe(
        "Are you from the U.S.?",
      );
      expect(applyRules("etc.?")).toBe("Etc.?");
      expect(applyRules("etc.?.")).toBe("Etc.?");
      expect(applyRules("watch out etc.!")).toBe("Watch out etc.!");
      expect(applyRules("watch out etc.!.")).toBe("Watch out etc.!");
    });

    it("preserves abbreviation periods before commas", () => {
      expect(applyRules("Apple Inc., which is huge")).toBe(
        "Apple Inc., which is huge",
      );
      expect(applyRules("Acme Co., yesterday")).toBe("Acme Co., yesterday");
      expect(applyRules("Acme Corp., yesterday")).toBe(
        "Acme Corp., yesterday",
      );
      expect(applyRules("we hired someone with a Ph.D., yeah")).toBe(
        "We hired someone with a Ph.D., yeah",
      );
      expect(applyRules("are you from the U.S., or Canada")).toBe(
        "Are you from the U.S., or Canada",
      );
    });

    it("collapses duplicated commas from STT plus dictated punctuation", () => {
      expect(applyRules("words about,, for fuck's sake")).toBe(
        "Words about, for fuck's sake",
      );
      expect(applyRules("but yeah,, I'm just saying")).toBe(
        "But yeah, I'm just saying",
      );
    });

    it("collapses period-comma artifacts left by filler removal", () => {
      expect(applyRules("the language should be fixed a little bit. um, yeah")).toBe(
        "The language should be fixed a little bit, yeah",
      );
      expect(applyRules("the language should be fixed a little bit., yeah")).toBe(
        "The language should be fixed a little bit, yeah",
      );
      expect(applyRules("pi is 3.14. um, yes")).toBe("Pi is 3.14, yes");
      expect(applyRules("version 3.14., yes")).toBe("Version 3.14, yes");
    });

    it("adds missing spaces around quoted prose", () => {
      expect(
        applyRules(
          'the syllabus shouldn\'t be"What were we through today?"or it should be"What would we talk about today?"We\'re still missing it',
        ),
      ).toBe(
        'The syllabus shouldn\'t be "What were we through today?" or it should be "What would we talk about today?" We\'re still missing it',
      );
      expect(applyRules('the sign says"hello?"then leave')).toBe(
        'The sign says "hello?" then leave',
      );
    });

    it("does not add prose spacing inside quoted code strings", () => {
      expect(
        applyRules(
          "condition question mark double quote yes double quote colon double quote no double quote",
        ),
      ).toBe('Condition?"yes":"no"');
      expect(applyRules('x="y?"z')).toBe('X="y?"z');
      expect(applyRules('x+"y?"z')).toBe('X+"y?"z');
      expect(applyRules('r"hello?"')).toBe('R"hello?"');
      expect(applyRules('path=r"c:?"')).toBe('Path=r"c:?"');
      expect(applyRules('br"hello?"')).toBe('Br"hello?"');
      expect(applyRules('path=rb"c:?"')).toBe('Path=rb"c:?"');
      expect(applyRules('for"What?"')).toBe('For "What?"');
    });

    it("preserves single commas from ordinary STT punctuation", () => {
      expect(applyRules("a very long, feedback")).toBe(
        "A very long, feedback",
      );
    });

    it("preserves dictated comma before nonterminal punctuation", () => {
      expect(applyRules("foo comma question mark bar")).toBe("Foo,? Bar");
      expect(applyRules("foo comma exclamation mark bar")).toBe("Foo,! Bar");
    });

    it("converts open/close paren", () => {
      expect(applyRules("open paren value close paren")).toBe("(value)");
    });

    it("converts colon and semicolon", () => {
      expect(applyRules("key colon value")).toBe("Key: value");
      expect(applyRules("first semicolon second")).toBe("First; second");
    });

    it("converts arrow", () => {
      expect(applyRules("input arrow output")).toBe("Input => output");
    });

    it("converts new line", () => {
      expect(applyRules("line one new line line two")).toContain("\n");
    });

    it("converts backtick", () => {
      expect(applyRules("backtick code backtick")).toBe("`code`");
    });

    it("converts multi-word operators before shorter operator phrases", () => {
      expect(applyRules("if value double equals null")).toBe("If value == null");
      expect(applyRules("if value triple equals undefined")).toBe(
        "If value === undefined",
      );
      expect(applyRules("if value not equals zero")).toBe("If value != 0");
      expect(applyRules("left double pipe right")).toBe("Left || right");
    });
  });

  // --- Stage 3: Case formatting commands ---
  describe("case formatting", () => {
    it("camel case", () => {
      // Case commands produce their own casing — auto-cap doesn't override
      // because the result starts with lowercase, but auto-cap capitalizes first char
      const result = applyRules("camel case foo bar baz");
      // Auto-cap makes first char uppercase, but camelCase starts lowercase
      // The rule engine runs case formatting before auto-cap
      expect(result).toMatch(/fooBarBaz/i);
    });

    it("snake case", () => {
      const result = applyRules("snake case foo bar baz");
      expect(result.toLowerCase()).toContain("foo_bar_baz");
    });

    it("pascal case", () => {
      expect(applyRules("pascal case foo bar")).toBe("FooBar");
    });

    it("kebab case", () => {
      const result = applyRules("kebab case foo bar");
      expect(result.toLowerCase()).toContain("foo-bar");
    });

    it("upper case / all caps", () => {
      expect(applyRules("all caps hello world")).toBe("HELLO WORLD");
    });
  });

  // --- Stage 4: Number formatting ---
  describe("number formatting", () => {
    it("converts simple numbers", () => {
      // "forty two" → "42", auto-cap doesn't affect numbers
      expect(applyRules("forty two")).toBe("42");
    });

    it("converts larger numbers", () => {
      expect(applyRules("one hundred twenty three")).toBe("123");
    });

    it("converts zero through ten", () => {
      expect(applyRules("zero")).toBe("0");
      expect(applyRules("ten")).toBe("10");
    });
  });

  // --- Stage 5: Tech vocabulary ---
  describe("tech vocabulary", () => {
    it("corrects common dev terms", () => {
      expect(applyRules("type script")).toBe("TypeScript");
      expect(applyRules("java script")).toBe("JavaScript");
    });

    it("corrects React hooks", () => {
      // useEffect starts with lowercase, auto-cap may capitalize it
      const result = applyRules("use effect");
      expect(result.toLowerCase()).toBe("useeffect");
    });

    it("corrects framework names", () => {
      expect(applyRules("next js")).toBe("Next.js");
      expect(applyRules("node js")).toBe("Node.js");
    });
  });

  describe("Phase 7 code-token preservation", () => {
    it("preserves common code tokens before punctuation cleanup", () => {
      expect(
        preserveCodeTokens("open paren foo bar close paren dot map"),
      ).toBe("(foo bar).map");
    });

    it("preserves hook and identifier tokens in mixed dictation", () => {
      const result = applyRules("תשתמש ב use effect בשביל on click handler");
      expect(result).toContain("useEffect");
      expect(result).toContain("onClick");
    });

    it("preserves lower-camel code terms at sentence starts", () => {
      expect(applyRules("use effect should rerun")).toBe(
        "useEffect should rerun",
      );
      expect(applyRules("on click handler should call use callback")).toBe(
        "onClick handler should call useCallback",
      );
      expect(applyRules("first sentence. use state keeps the count")).toBe(
        "First sentence. useState keeps the count",
      );
    });
  });

  // --- Stage 6: Auto-capitalization ---
  describe("auto-capitalization", () => {
    it("capitalizes first word", () => {
      expect(applyRules("hello world")).toBe("Hello world");
    });

    it("capitalizes after period", () => {
      expect(applyRules("first sentence. second sentence")).toBe(
        "First sentence. Second sentence",
      );
    });

    it("capitalizes after question mark", () => {
      expect(applyRules("what? something else")).toBe("What? Something else");
    });

    it("capitalizes common I contractions", () => {
      expect(applyRules("i'll check if i've finished")).toBe(
        "I'll check if I've finished",
      );
    });

    it("preserves code index variables while capitalizing prose pronouns", () => {
      expect(applyRules("array open bracket i close bracket equals value")).toBe(
        "Array [i] = value",
      );
      expect(applyRules("let i equals zero")).toBe("Let i = 0");
      expect(applyRules("if i can fix it")).toBe("If I can fix it");
    });
  });

  describe("stage toggles", () => {
    it("does not normalize percent phrases when number formatting is disabled", () => {
      const config: RulesConfig = {
        disabledStages: new Set(["numbers"]),
      };

      expect(applyRules("i'm 100 sure", config)).toBe("I'm 100 sure");
    });
  });

  describe("percent phrase normalization", () => {
    it("normalizes common confidence percentages without corrupting ordinary sure phrases", () => {
      expect(applyRules("i'm 100 sure")).toBe("I'm 100% sure");
      expect(applyRules("i am a hundred percent period")).toBe("I am 100%.");
      expect(applyRules("this is a hundred percent reliable fix")).toBe(
        "This is a 100% reliable fix",
      );
      expect(applyRules("two sure ways")).toBe("2 sure ways");
    });
  });

  // --- Stage 7: Custom aliases ---
  describe("custom aliases", () => {
    it("applies custom aliases", () => {
      const config: RulesConfig = {
        aliases: {
          "brain layer": "BrainLayer",
          "voice bar": "VoiceBar",
        },
      };
      expect(
        applyRules("the brain layer is connected to voice bar", config),
      ).toBe("The BrainLayer is connected to VoiceBar");
    });
  });

  // --- Performance ---
  describe("performance", () => {
    it("runs in under 5ms for typical input", () => {
      const input =
        "um basically I think the function should uh take the use state hook and like return the value comma you know comma with the type script interface";
      const start = performance.now();
      for (let i = 0; i < 100; i++) {
        applyRules(input);
      }
      const elapsed = performance.now() - start;
      const perCall = elapsed / 100;
      expect(perCall).toBeLessThan(5);
    });
  });
});
