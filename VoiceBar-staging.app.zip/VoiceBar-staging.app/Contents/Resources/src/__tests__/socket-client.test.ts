/**
 * Tests for socket-client.ts — MCP server as client connecting to VoiceBar server.
 *
 * TDD RED phase: these tests define the expected behavior of the inverted
 * architecture where VoiceBar is the server and MCP instances connect as clients.
 *
 * Each test spins up a mock VoiceBar server (Bun.listen on a temp Unix socket)
 * and tests the client's behavior.
 */
import { describe, it, expect, beforeEach, afterEach } from "bun:test";
import { existsSync, unlinkSync } from "fs";
import type { SocketEvent, SocketCommand } from "../socket-protocol";

// Use a unique test socket path to avoid conflicts with real VoiceBar
const TEST_SOCKET = "/tmp/voicelayer-test-client.sock";

// --- Mock VoiceBar server helper ---

type MockServer = {
  server: ReturnType<typeof Bun.listen>;
  received: string[];
  clients: Set<any>;
  sendToAll: (data: string) => void;
  stop: () => void;
};

function createMockVoiceBarServer(socketPath: string): MockServer {
  const received: string[] = [];
  const clients = new Set<any>();

  const server = Bun.listen<{ buffer: string }>({
    unix: socketPath,
    socket: {
      open(socket) {
        socket.data = { buffer: "" };
        clients.add(socket);
      },
      data(socket, raw) {
        socket.data.buffer += raw.toString("utf-8");
        const lines = socket.data.buffer.split("\n");
        socket.data.buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (line.trim()) received.push(line);
        }
      },
      close(socket) {
        clients.delete(socket);
      },
      error(socket) {
        clients.delete(socket);
      },
      drain() {},
    },
  });

  return {
    server,
    received,
    clients,
    sendToAll(data: string) {
      for (const client of clients) {
        client.write(data);
      }
    },
    stop() {
      server.stop(true);
      try {
        unlinkSync(socketPath);
      } catch {}
    },
  };
}

async function waitFor(
  predicate: () => boolean,
  timeoutMs = 3000,
  intervalMs = 50,
): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return true;
    await Bun.sleep(intervalMs);
  }
  return predicate();
}

function parseReceived(mockServer: MockServer): Record<string, unknown>[] {
  return mockServer.received.map((line) => JSON.parse(line));
}

// --- Tests ---

describe("socket-client", () => {
  let mockServer: MockServer | null = null;

  beforeEach(() => {
    // Clean up any stale socket
    try {
      unlinkSync(TEST_SOCKET);
    } catch {}
  });

  afterEach(async () => {
    // Import and disconnect client
    try {
      const { disconnectFromBar } = await import("../socket-client");
      disconnectFromBar();
    } catch {}
    // Stop mock server
    mockServer?.stop();
    mockServer = null;
    try {
      unlinkSync(TEST_SOCKET);
    } catch {}
  });

  it("connectToBar connects to a listening Unix socket", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, isConnected } = await import("../socket-client");
    connectToBar(TEST_SOCKET);

    // Wait for connection
    await Bun.sleep(200);
    expect(isConnected()).toBe(true);
    expect(mockServer.clients.size).toBe(1);
  });

  it("broadcast sends NDJSON event to the server", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, broadcast } = await import("../socket-client");
    connectToBar(TEST_SOCKET);
    await Bun.sleep(200);

    const event: SocketEvent = {
      type: "state",
      state: "speaking",
      text: "hello",
    };
    broadcast(event);

    expect(
      await waitFor(() =>
        parseReceived(mockServer!).some(
          (message) =>
            message.type === "state" && message.state === "speaking",
        ),
      ),
    ).toBe(true);
    const parsed = parseReceived(mockServer).find(
      (message) => message.type === "state",
    )!;
    expect(parsed.type).toBe("state");
    expect(parsed.state).toBe("speaking");
    expect(parsed.text).toBe("hello");
  });

  it("sends a client_hello that is not command-eligible by default", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar } = await import("../socket-client");
    connectToBar(TEST_SOCKET);

    expect(
      await waitFor(() =>
        parseReceived(mockServer!).some(
          (message) => message.type === "client_hello",
        ),
      ),
    ).toBe(true);
    const hello = parseReceived(mockServer).find(
      (message) => message.type === "client_hello",
    )!;
    expect(hello.role).toBe("mcp-server");
    expect(hello.accepts_commands).toBe(false);
    expect(hello.voicebar_socket_path).toBe(TEST_SOCKET);
  });

  it("can declare the persistent daemon as the command owner", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar } = await import("../socket-client");
    connectToBar(TEST_SOCKET, { role: "mcp-daemon", acceptsCommands: true });

    expect(
      await waitFor(() =>
        parseReceived(mockServer!).some(
          (message) => message.type === "client_hello",
        ),
      ),
    ).toBe(true);
    const hello = parseReceived(mockServer).find(
      (message) => message.type === "client_hello",
    )!;
    expect(hello.role).toBe("mcp-daemon");
    expect(hello.accepts_commands).toBe(true);
  });

  it("onCommand receives parsed commands from the server", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, onCommand } = await import("../socket-client");
    const commands: SocketCommand[] = [];
    onCommand((cmd) => commands.push(cmd));

    connectToBar(TEST_SOCKET);
    await Bun.sleep(200);

    // Server sends a command to the client
    mockServer.sendToAll('{"cmd":"stop"}\n');
    await Bun.sleep(100);

    expect(commands.length).toBe(1);
    expect(commands[0].cmd).toBe("stop");
  });

  it("auto-reconnects when connection drops", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, isConnected } = await import("../socket-client");
    connectToBar(TEST_SOCKET);
    await Bun.sleep(200);
    expect(isConnected()).toBe(true);

    // Kill the server
    mockServer.stop();
    await Bun.sleep(300);
    expect(isConnected()).toBe(false);

    // Restart the server — client should auto-reconnect
    mockServer = createMockVoiceBarServer(TEST_SOCKET);
    // Wait for reconnect (first backoff is 1s, plus scheduler load in full suite)
    expect(await waitFor(() => isConnected())).toBe(true);
    expect(isConnected()).toBe(true);
  });

  it("restores command and broadcast flow after reconnect", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, onCommand, broadcast, isConnected } =
      await import("../socket-client");
    const commands: SocketCommand[] = [];
    onCommand((cmd) => commands.push(cmd));

    connectToBar(TEST_SOCKET);
    await Bun.sleep(200);
    expect(isConnected()).toBe(true);

    mockServer.stop();
    await Bun.sleep(300);
    expect(isConnected()).toBe(false);

    mockServer = createMockVoiceBarServer(TEST_SOCKET);
    expect(await waitFor(() => isConnected())).toBe(true);
    expect(isConnected()).toBe(true);

    broadcast({ type: "state", state: "idle" });
    mockServer.sendToAll('{"cmd":"health"}\n');

    expect(
      await waitFor(() =>
        mockServer!.received.includes('{"type":"state","state":"idle"}'),
      ),
    ).toBe(true);
    expect(await waitFor(() => commands.at(-1)?.cmd === "health")).toBe(true);
    expect(commands.at(-1)).toEqual({ cmd: "health" });
  });

  it("broadcast is no-op when disconnected", async () => {
    const { broadcast } = await import("../socket-client");
    // No server running, not connected — should not throw
    expect(() => {
      broadcast({ type: "state", state: "idle" });
    }).not.toThrow();
  });

  it("disconnectFromBar stops reconnection attempts", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, disconnectFromBar, isConnected } =
      await import("../socket-client");
    connectToBar(TEST_SOCKET);
    await Bun.sleep(200);
    expect(isConnected()).toBe(true);

    // Disconnect intentionally
    disconnectFromBar();
    await Bun.sleep(100);
    expect(isConnected()).toBe(false);

    // Kill and restart server — should NOT auto-reconnect
    mockServer.stop();
    mockServer = createMockVoiceBarServer(TEST_SOCKET);
    await Bun.sleep(2000);
    // Should still be disconnected
    expect(isConnected()).toBe(false);
    expect(mockServer.clients.size).toBe(0);
  });

  it("handles NDJSON framing across TCP chunks", async () => {
    mockServer = createMockVoiceBarServer(TEST_SOCKET);

    const { connectToBar, onCommand } = await import("../socket-client");
    const commands: SocketCommand[] = [];
    onCommand((cmd) => commands.push(cmd));

    connectToBar(TEST_SOCKET);
    await Bun.sleep(200);

    // Send a partial chunk, then the rest
    mockServer.sendToAll('{"cmd":"sto');
    await Bun.sleep(50);
    mockServer.sendToAll('p"}\n{"cmd":"replay"}\n');
    await Bun.sleep(100);

    expect(commands.length).toBe(2);
    expect(commands[0].cmd).toBe("stop");
    expect(commands[1].cmd).toBe("replay");
  });
});
